package com.iswherevivek.sportsball.presentation.addleague

import com.iswherevivek.sportsball.domain.model.ClubList

data class AddState(
    val teams:ClubList?=null
)
