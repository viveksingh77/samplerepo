package com.iswherevivek.sportsball.utils

object Constants {
    const val BASE_URL ="https://www.thesportsdb.com/api/v1/json/3/"
    const val SPORT_DATABASE_NAME="sports_db"
}