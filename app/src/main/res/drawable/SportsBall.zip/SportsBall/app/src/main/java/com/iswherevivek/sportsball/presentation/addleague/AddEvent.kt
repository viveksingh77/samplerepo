package com.iswherevivek.sportsball.presentation.addleague

sealed class AddEvent {
    object ShowRoomData:AddEvent()
}